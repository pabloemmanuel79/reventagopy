export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyArK-aaI10rseB05MrRF5VZVXoeAL9tW4w",
    authDomain: "reventago-19068.firebaseapp.com",
    projectId: "reventago-19068",
    storageBucket: "reventago-19068.firebasestorage.app",
    messagingSenderId: "992982238670",
    appId: "1:992982238670:web:a285b3dc64bfba6580d79f"
  }
};
