import {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
} from "./chunk-WQQ6SXZM.js";
import "./chunk-BRJI7AQO.js";
import "./chunk-Z3C7KKU6.js";
import "./chunk-TUM2EQFD.js";
import "./chunk-LXCXGR42.js";
import "./chunk-YCBSMCZA.js";
import "./chunk-FVETPLIC.js";
export {
  AngularFireAuth,
  AngularFireAuthModule,
  LANGUAGE_CODE,
  PERSISTENCE,
  SETTINGS,
  TENANT_ID,
  USE_DEVICE_LANGUAGE,
  USE_EMULATOR,
  ɵauthFactory
};
